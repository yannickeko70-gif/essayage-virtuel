import { useState, useRef } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import productService from "../../services/productService";

const S = {
  ink: "#050505", red: "#E30613", cream: "#FFFFFF",
  warm: "#F6F6F6", muted: "#5F5F5F", border: "rgba(5,5,5,0.12)",
};

export default function TryOn() {
  const [searchParams] = useSearchParams();
  const { addItem } = useCart();

  const productId = searchParams.get("product");
  const defaultProduct = productId
    ? productService.getById(productId)
    : productService.getFeatured()[0];

  const [selectedProduct, setSelectedProduct] = useState(defaultProduct);
  const [selectedSize, setSelectedSize] = useState(defaultProduct?.sizes[2] || "M");
  const [selectedColor, setSelectedColor] = useState(defaultProduct?.colors[0]);
  const [mode, setMode] = useState("webcam"); // "photo" | "webcam"
  const [hasPhoto, setHasPhoto] = useState(false);
  const [aiScore, setAiScore] = useState(null);
  const fileRef = useRef(null);

  const allProducts = productService.getAll();

  const simulateUpload = () => {
    setHasPhoto(true);
    // Simulation score IA
    setTimeout(() => {
      setAiScore(Math.floor(75 + Math.random() * 23));
    }, 1500);
  };

  const handleAddToCart = () => {
    if (selectedProduct) {
      addItem({ ...selectedProduct, size: selectedSize, color: selectedColor });
    }
  };

  return (
    <main style={{ paddingTop: 64, fontFamily: "'DM Sans', sans-serif", minHeight: "100vh" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 400px", minHeight: "calc(100vh - 64px)" }}>

        {/* ── Zone de prévisualisation ─────────────────────────────────────── */}
        <div style={{ background: "linear-gradient(135deg, #050505, #191919)", position: "relative", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          {/* Fond ambiant */}
          <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 30%, rgba(47,83,120,0.22), transparent 68%)" }} />

          {/* Status */}
          <div style={{
            position: "absolute", top: 24, left: "50%", transform: "translateX(-50%)",
            background: "rgba(227,6,19,0.92)", color: "#fff",
            fontSize: 11, fontWeight: 600, letterSpacing: "1.5px", textTransform: "uppercase",
            padding: "6px 16px", borderRadius: 100,
            display: "flex", alignItems: "center", gap: 8,
          }}>
            <span style={{ width: 6, height: 6, background: "#fff", borderRadius: "50%", display: "inline-block" }} />
            {hasPhoto ? "Analyse en cours…" : "En attente…"}
          </div>

          {/* Zone upload / silhouette */}
          {!hasPhoto ? (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, zIndex: 1 }}>
              <div
                onClick={simulateUpload}
                style={{
                  width: 120, height: 120, borderRadius: "50%",
                  border: "2px dashed rgba(227,6,19,0.45)",
                  display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                  cursor: "pointer", background: "rgba(227,6,19,0.08)", gap: 8,
                }}
              >
                <span style={{ fontSize: 40 }}>📷</span>
                <span style={{ fontSize: 11, letterSpacing: "1px", textTransform: "uppercase", color: "rgba(255,255,255,0.5)" }}>Charger</span>
              </div>
              <div style={{ textAlign: "center", color: "rgba(255,255,255,0.7)" }}>
                <strong style={{ display: "block", marginBottom: 4 }}>Importez votre photo</strong>
                <span style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>ou activez la webcam pour commencer</span>
              </div>
              <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={simulateUpload} />
            </div>
          ) : (
            /* Silhouette avec vêtement */
            <div style={{ position: "relative", width: 240, height: 380, zIndex: 1 }}>
              <div style={{ width: "100%", height: "100%", position: "relative" }}>
                {/* Silhouette placeholder */}
                <div style={{
                  width: "100%", height: "100%",
                  background: "rgba(255,255,255,0.06)", borderRadius: 20,
                  display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                  border: "1px solid rgba(255,255,255,0.08)",
                }}>
                  {/* Overlay vêtement */}
                  <div style={{
                    width: "70%", height: "55%",
                    background: "rgba(227,6,19,0.18)",
                    border: "2px solid rgba(227,6,19,0.45)",
                    borderRadius: 12,
                    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                    gap: 8,
                  }}>
                    <span style={{ fontSize: 48 }}>{selectedProduct?.emoji || "👗"}</span>
                    <span style={{
                      background: S.red, color: "#fff",
                      fontSize: 10, fontWeight: 700, letterSpacing: "1px", textTransform: "uppercase",
                      padding: "4px 12px", borderRadius: 100,
                    }}>
                      {selectedProduct?.name || "Vêtement"}
                    </span>
                  </div>

                  {/* Points de détection */}
                  {[
                    { top: "10%", left: "50%", transform: "translateX(-50%)" },
                    { top: "28%", left: "30%" },
                    { top: "28%", right: "30%" },
                    { top: "55%", left: "35%" },
                    { top: "55%", right: "35%" },
                  ].map((pos, i) => (
                    <div key={i} style={{
                      position: "absolute", width: 8, height: 8,
                      background: S.red, borderRadius: "50%",
                      boxShadow: "0 0 0 3px rgba(227,6,19,0.3)",
                      ...pos,
                    }} />
                  ))}

                  {/* Ligne de scan */}
                  <div style={{
                    position: "absolute", left: 0, right: 0,
                    height: 2, background: "linear-gradient(90deg, transparent, rgba(227,6,19,0.6), transparent)",
                    animation: "scanline 2s ease-in-out infinite",
                    top: "50%",
                  }} />
                </div>
              </div>
            </div>
          )}

          {/* Contrôles */}
          <div style={{
            position: "absolute", bottom: 24, left: "50%", transform: "translateX(-50%)",
            display: "flex", gap: 8,
          }}>
            {[
              { id: "photo", label: "📷 Photo" },
              { id: "webcam", label: "🎥 Webcam" },
              { id: "reset", label: "⟳ Changer" },
            ].map((btn) => (
              <button
                key={btn.id}
                onClick={() => {
                  if (btn.id === "reset") { setHasPhoto(false); setAiScore(null); }
                  else setMode(btn.id);
                }}
                style={{
                  padding: "8px 18px", borderRadius: 100,
                  fontSize: 12, fontWeight: 500, letterSpacing: "1px",
                  border: `1.5px solid ${mode === btn.id ? S.red : "rgba(255,255,255,0.2)"}`,
                  background: mode === btn.id ? S.red : "transparent",
                  color: mode === btn.id ? "#fff" : "rgba(255,255,255,0.7)",
                  cursor: "pointer",
                }}
              >
                {btn.label}
              </button>
            ))}
          </div>
        </div>

        {/* ── Panel latéral ────────────────────────────────────────────────── */}
        <div style={{ background: S.cream, borderLeft: `1px solid ${S.border}`, display: "flex", flexDirection: "column", overflowY: "auto" }}>

          {/* Article sélectionné */}
          <div style={{ padding: 24, borderBottom: `1px solid ${S.border}` }}>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "2px", textTransform: "uppercase", color: S.muted, marginBottom: 16 }}>
              Article sélectionné
            </div>
            <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
              <div style={{
                width: 64, height: 80, background: "linear-gradient(160deg,#f5f0e8,#ede5d8)",
                borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 28, flexShrink: 0,
              }}>
                {selectedProduct?.emoji || "👗"}
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>{selectedProduct?.name}</div>
                <div style={{ fontSize: 12, color: S.muted, marginTop: 2 }}>Collection 2025</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, fontWeight: 600, marginTop: 4, color: S.red }}>
                  {selectedProduct?.price.toLocaleString("fr-FR")} FCFA
                </div>
              </div>
            </div>
          </div>

          {/* Taille + Couleur */}
          <div style={{ padding: 24, borderBottom: `1px solid ${S.border}` }}>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "2px", textTransform: "uppercase", color: S.muted, marginBottom: 12 }}>
              Taille
            </div>
            <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
              {(selectedProduct?.sizes || ["XS","S","M","L","XL"]).map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedSize(s)}
                  style={{
                    width: 40, height: 40, border: `1.5px solid ${selectedSize === s ? S.ink : S.border}`,
                    background: selectedSize === s ? S.ink : "transparent",
                    color: selectedSize === s ? "#fff" : S.ink,
                    borderRadius: 8, fontSize: 12, fontWeight: 500, cursor: "pointer",
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "2px", textTransform: "uppercase", color: S.muted, marginBottom: 12 }}>
              Couleur
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {(selectedProduct?.colors || []).map((c) => (
                <div
                  key={c}
                  onClick={() => setSelectedColor(c)}
                  style={{
                    width: 28, height: 28, borderRadius: "50%", background: c,
                    cursor: "pointer",
                    border: selectedColor === c ? `3px solid ${S.ink}` : "3px solid transparent",
                    outline: selectedColor === c ? `1px solid ${S.ink}` : "none",
                  }}
                />
              ))}
            </div>
          </div>

          {/* Score IA */}
          <div style={{ padding: 24, borderBottom: `1px solid ${S.border}` }}>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "2px", textTransform: "uppercase", color: S.muted, marginBottom: 16 }}>
              Score de compatibilité IA
            </div>
            <div style={{ background: "linear-gradient(135deg, #050505, #191919)", borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", marginBottom: 8 }}>Correspondance morphologie</div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 42, fontWeight: 300, color: S.red }}>
                {aiScore ? `${aiScore}%` : "—"}
              </div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 12 }}>
                {aiScore ? "Excellent — morphologie compatible" : "En attente d'analyse…"}
              </div>
              <div style={{ height: 4, background: "rgba(255,255,255,0.1)", borderRadius: 2 }}>
                <div style={{ height: "100%", width: `${aiScore || 0}%`, background: S.red, borderRadius: 2, transition: "width 1s ease" }} />
              </div>
            </div>
          </div>

          {/* Recommandations */}
          {aiScore && (
            <div style={{ padding: 24, borderBottom: `1px solid ${S.border}` }}>
              <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "2px", textTransform: "uppercase", color: S.muted, marginBottom: 12 }}>
                Recommandations IA
              </div>
              <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 8 }}>
                {[
                  "Convient parfaitement à votre morphologie",
                  `Taille ${selectedSize} recommandée selon vos mesures`,
                  "La couleur sélectionnée valorise votre teint",
                  "Accessoirisez avec une ceinture fine",
                ].map((tip) => (
                  <li key={tip} style={{ fontSize: 13, color: S.muted, paddingLeft: 16, position: "relative" }}>
                    <span style={{ position: "absolute", left: 0, color: S.red }}>✓</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Changer de vêtement */}
          <div style={{ padding: 24, borderBottom: `1px solid ${S.border}` }}>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "2px", textTransform: "uppercase", color: S.muted, marginBottom: 12 }}>
              Changer de vêtement
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {allProducts.slice(0, 4).map((p) => (
                <button
                  key={p.id}
                  onClick={() => { setSelectedProduct(p); setSelectedSize(p.sizes[1] || p.sizes[0]); setSelectedColor(p.colors[0]); }}
                  style={{
                    display: "flex", alignItems: "center", gap: 12,
                    padding: "10px 12px", borderRadius: 10, cursor: "pointer",
                    border: `1.5px solid ${selectedProduct?.id === p.id ? S.ink : S.border}`,
                    background: selectedProduct?.id === p.id ? "#f6f6f6" : "transparent",
                    textAlign: "left",
                  }}
                >
                  <span style={{ fontSize: 22 }}>{p.emoji}</span>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{p.name}</div>
                    <div style={{ fontSize: 11, color: S.muted }}>{p.price.toLocaleString("fr-FR")} FCFA</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div style={{ padding: 24, marginTop: "auto" }}>
            <button
              onClick={handleAddToCart}
              style={{
                width: "100%", padding: "16px 24px",
                background: "linear-gradient(135deg, #050505, #222)",
                color: "#fff", border: "none", borderRadius: 12,
                fontSize: 14, fontWeight: 600, cursor: "pointer",
                letterSpacing: "0.5px", transition: "all .2s",
              }}
            >
              Ajouter au panier — {selectedProduct?.price.toLocaleString("fr-FR")} FCFA
            </button>
            <Link
              to={`/produit/${selectedProduct?.id}`}
              style={{ display: "block", textAlign: "center", marginTop: 12, fontSize: 13, color: S.muted, textDecoration: "none" }}
            >
              Voir la fiche produit →
            </Link>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scanline {
          0%, 100% { top: 20%; opacity: 1; }
          50% { top: 80%; opacity: 0.5; }
        }
      `}</style>
    </main>
  );
}