export default function Login() {
  return <div className="pt-20 container mx-auto">Page cart</div>;
}