import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import productService from "../../services/productService";

const S = {
  ink: "#050505", red: "#E30613", cream: "#FFFFFF",
  warm: "#F6F6F6", muted: "#5F5F5F", border: "rgba(5,5,5,0.12)",
};

export default function ProductDetail() {
  const { id } = useParams();
  const { addItem } = useCart();

  const product = productService.getById(id);
  const similar = productService.getSimilar(id);

  const [selectedSize, setSelectedSize] = useState(product?.sizes[2] || "M");
  const [selectedColor, setSelectedColor] = useState(product?.colors[0]);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <div style={{ paddingTop: 64, display: "flex", alignItems: "center", justifyContent: "center", minHeight: "80vh", flexDirection: "column", gap: 16 }}>
        <span style={{ fontSize: 48 }}>🔍</span>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 32, fontWeight: 300 }}>Produit introuvable</h2>
        <Link to="/catalogue" style={{ color: S.red, textDecoration: "none", fontSize: 14 }}>← Retour au catalogue</Link>
      </div>
    );
  }

  const handleAdd = () => {
    addItem({ ...product, size: selectedSize, color: selectedColor, quantity: qty });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <main style={{ paddingTop: 64, fontFamily: "'DM Sans', sans-serif", minHeight: "100vh" }}>

      {/* Breadcrumb */}
      <div style={{ padding: "16px 80px", borderBottom: `1px solid ${S.border}`, fontSize: 13, color: S.muted }}>
        <Link to="/" style={{ color: S.muted, textDecoration: "none" }}>Accueil</Link>
        {" · "}
        <Link to="/catalogue" style={{ color: S.muted, textDecoration: "none" }}>Catalogue</Link>
        {" · "}
        <span style={{ color: S.ink }}>{product.name}</span>
      </div>

      {/* Contenu principal */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", minHeight: "calc(100vh - 64px - 49px)" }}>

        {/* Galerie */}
        <div style={{ position: "sticky", top: 64, height: "calc(100vh - 64px)", background: "linear-gradient(160deg,#f5f0e8,#ede5d8)", display: "flex", flexDirection: "column" }}>
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
            <span style={{ fontSize: 180, opacity: 0.2 }}>{product.emoji}</span>
            {/* Badge AR */}
            <div style={{
              position: "absolute", top: 24, right: 24,
              background: S.ink, color: S.cream,
              padding: "8px 16px", borderRadius: 100,
              fontSize: 11, fontWeight: 600, letterSpacing: "1.5px", textTransform: "uppercase",
              display: "flex", alignItems: "center", gap: 6,
            }}>
              ✨ Essayage AR
            </div>
          </div>
          {/* Thumbnails */}
          <div style={{ display: "flex", gap: 8, padding: "16px 24px", borderTop: `1px solid ${S.border}` }}>
            {[product.emoji, "📷", "🎨"].map((e, i) => (
              <div key={i} style={{
                width: 72, height: 90, borderRadius: 10,
                background: i === 0 ? "rgba(5,5,5,0.08)" : "rgba(5,5,5,0.04)",
                cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
                border: i === 0 ? `2px solid ${S.ink}` : "2px solid transparent",
                fontSize: 24,
              }}>
                {e}
              </div>
            ))}
          </div>
        </div>

        {/* Infos produit */}
        <div style={{ padding: "48px 64px", overflowY: "auto" }}>
          {/* Catégorie tag */}
          <span style={{ fontSize: 11, fontWeight: 500, letterSpacing: "2px", textTransform: "uppercase", color: S.red, display: "block", marginBottom: 16 }}>
            {product.subcategory}
          </span>

          {/* Nom */}
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 42, fontWeight: 300, lineHeight: 1.1, margin: "0 0 16px" }}>
            {product.name}
          </h1>

          {/* Note */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 24 }}>
            <span style={{ color: S.red }}>{"★".repeat(Math.round(product.rating))}</span>
            <span style={{ fontSize: 13, color: S.muted }}>{product.rating} ({product.reviews} avis)</span>
          </div>

          {/* Prix */}
          <div style={{ marginBottom: 32 }}>
            {product.oldPrice && (
              <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 20, color: S.muted, textDecoration: "line-through", marginRight: 12 }}>
                {product.oldPrice.toLocaleString("fr-FR")} FCFA
              </span>
            )}
            <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 38, fontWeight: 600, color: S.ink }}>
              {product.price.toLocaleString("fr-FR")} <small style={{ fontSize: 20 }}>FCFA</small>
            </span>
          </div>

          {/* Description */}
          <p style={{ fontSize: 15, color: S.muted, lineHeight: 1.8, margin: "0 0 32px", borderBottom: `1px solid ${S.border}`, paddingBottom: 32 }}>
            {product.description}
          </p>

          {/* Taille */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <span style={{ fontSize: 13, fontWeight: 500, letterSpacing: "1px", textTransform: "uppercase" }}>Taille</span>
              <a href="#" style={{ fontSize: 12, color: S.red, textDecoration: "none" }}>Guide des tailles</a>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedSize(s)}
                  style={{
                    width: 44, height: 44,
                    border: `1.5px solid ${selectedSize === s ? S.ink : S.border}`,
                    background: selectedSize === s ? S.ink : "transparent",
                    color: selectedSize === s ? "#fff" : S.ink,
                    borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: "pointer",
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Couleur */}
          <div style={{ marginBottom: 32 }}>
            <span style={{ fontSize: 13, fontWeight: 500, letterSpacing: "1px", textTransform: "uppercase", display: "block", marginBottom: 12 }}>
              Couleur
            </span>
            <div style={{ display: "flex", gap: 10 }}>
              {product.colors.map((c) => (
                <div
                  key={c}
                  onClick={() => setSelectedColor(c)}
                  style={{
                    width: 32, height: 32, borderRadius: "50%", background: c, cursor: "pointer",
                    border: selectedColor === c ? `3px solid ${S.ink}` : "3px solid transparent",
                    outline: selectedColor === c ? `2px solid ${S.ink}` : "none",
                    outlineOffset: 2,
                  }}
                />
              ))}
            </div>
          </div>

          {/* Quantité + CTA */}
          <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
            {/* Quantité */}
            <div style={{ display: "flex", alignItems: "center", border: `1.5px solid ${S.border}`, borderRadius: 10, overflow: "hidden" }}>
              <button onClick={() => setQty(Math.max(1, qty - 1))} style={{ width: 44, height: 54, border: "none", background: "transparent", cursor: "pointer", fontSize: 18 }}>−</button>
              <span style={{ width: 40, textAlign: "center", fontSize: 14, fontWeight: 500 }}>{qty}</span>
              <button onClick={() => setQty(qty + 1)} style={{ width: 44, height: 54, border: "none", background: "transparent", cursor: "pointer", fontSize: 18 }}>+</button>
            </div>
            {/* Ajouter */}
            <button
              onClick={handleAdd}
              style={{
                flex: 1, padding: "16px 24px",
                background: added ? "#16a085" : "linear-gradient(135deg, #050505, #222)",
                color: "#fff", border: "none", borderRadius: 10,
                fontSize: 14, fontWeight: 600, cursor: "pointer",
                transition: "all .3s",
              }}
            >
              {added ? "✓ Ajouté au panier !" : `Ajouter au panier — ${(product.price * qty).toLocaleString("fr-FR")} FCFA`}
            </button>
          </div>

          {/* Essayer */}
          <Link
            to={`/essayage?product=${product.id}`}
            style={{
              display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
              width: "100%", padding: "14px 24px",
              background: S.red, color: "#fff", border: "none", borderRadius: 10,
              fontSize: 14, fontWeight: 600, cursor: "pointer", textDecoration: "none",
              marginBottom: 32,
            }}
          >
            ✨ Essayer virtuellement
          </Link>

          {/* Infos livraison */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12, fontSize: 13, color: S.muted }}>
            <div>🚚 Livraison gratuite à Douala dès 20 000 FCFA</div>
            <div>↩️ Retours gratuits sous 30 jours</div>
            <div>🔒 Paiement sécurisé — MTN, Orange Money, Visa</div>
          </div>
        </div>
      </div>

      {/* Produits similaires */}
      {similar.length > 0 && (
        <section style={{ padding: "64px 80px" }}>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 36, fontWeight: 300, marginBottom: 32 }}>
            Vous aimerez aussi
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 24 }}>
            {similar.map((p) => (
              <Link key={p.id} to={`/produit/${p.id}`} style={{ textDecoration: "none", color: "inherit" }}>
                <div style={{ background: "#fff", borderRadius: 18, overflow: "hidden", border: `1px solid ${S.border}`, cursor: "pointer" }}>
                  <div style={{ aspectRatio: "3/4", background: "linear-gradient(160deg,#f5f0e8,#ede5d8)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span style={{ fontSize: 64, opacity: 0.3 }}>{p.emoji}</span>
                  </div>
                  <div style={{ padding: "16px 18px" }}>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{p.name}</div>
                    <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 18, fontWeight: 600, marginTop: 4 }}>
                      {p.price.toLocaleString("fr-FR")} FCFA
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}