import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useCart } from "../../context/CartContext";

export default function Navbar() {
  const { totalItems } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/catalogue?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery("");
    }
  };

  const navLinks = [
    { to: "/", label: "Accueil" },
    { to: "/catalogue", label: "Catalogue" },
    { to: "/essayage", label: "✨ Essayer" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#F9F9F9]/95 backdrop-blur border-b border-black/10 h-16">
      <div className="max-w-7xl mx-auto h-full px-6 flex items-center gap-8">
        {/* Logo */}
        <Link
          to="/"
          className="font-['Cormorant_Garamond'] text-2xl font-semibold tracking-widest text-[#1A1A1A] mr-auto"
        >
          CF<span className="text-[#5B7FA6]">PD</span>
        </Link>

        {/* Liens desktop */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              className={({ isActive }) =>
                `text-xs font-medium tracking-widest uppercase transition-colors ${
                  isActive ? "text-[#1A1A1A]" : "text-[#666A70] hover:text-[#1A1A1A]"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        {/* Icônes */}
        <div className="flex items-center gap-2">
          {/* Recherche */}
          <button
            onClick={() => setSearchOpen((o) => !o)}
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-white hover:shadow-md transition-all text-[#1A1A1A]"
            aria-label="Rechercher"
          >
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
          </button>

          {/* Panier */}
          <Link
            to="/panier"
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-white hover:shadow-md transition-all text-[#1A1A1A] relative"
            aria-label="Panier"
          >
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
              <line x1="3" y1="6" x2="21" y2="6" />
              <path d="M16 10a4 4 0 0 1-8 0" />
            </svg>
            {totalItems > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#C0392B] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                {totalItems > 9 ? "9+" : totalItems}
              </span>
            )}
          </Link>

          {/* Compte */}
          <Link
            to="/compte"
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-white hover:shadow-md transition-all text-[#1A1A1A]"
            aria-label="Mon compte"
          >
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
          </Link>

          {/* Burger mobile */}
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className="md:hidden w-10 h-10 flex items-center justify-center rounded-xl hover:bg-white transition-all"
            aria-label="Menu"
          >
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              {menuOpen ? (
                <path d="M18 6 6 18M6 6l12 12" />
              ) : (
                <>
                  <line x1="3" y1="6" x2="21" y2="6" />
                  <line x1="3" y1="12" x2="21" y2="12" />
                  <line x1="3" y1="18" x2="21" y2="18" />
                </>
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Barre de recherche */}
      {searchOpen && (
        <div className="bg-white border-b border-black/10 px-6 py-3">
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto flex gap-3">
            <input
              autoFocus
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher un vêtement..."
              className="flex-1 border border-black/15 rounded-lg px-4 py-2 text-sm outline-none focus:border-[#5B7FA6] transition-colors"
            />
            <button
              type="submit"
              className="bg-[#1A1A1A] text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-[#C0392B] transition-colors"
            >
              Chercher
            </button>
          </form>
        </div>
      )}

      {/* Menu mobile */}
      {menuOpen && (
        <div className="md:hidden bg-white border-b border-black/10 px-6 py-4 flex flex-col gap-4">
          {navLinks.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              onClick={() => setMenuOpen(false)}
              className={({ isActive }) =>
                `text-sm font-medium tracking-wider uppercase transition-colors ${
                  isActive ? "text-[#C0392B]" : "text-[#1A1A1A]"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>
      )}
    </nav>
  );
}